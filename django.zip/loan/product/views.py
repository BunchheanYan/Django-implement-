from django.shortcuts import render, redirect 
from django.views.generic import View, TemplateView  
from django.views import generic 
from django.core.paginator import Paginator 
from django.http import HttpResponse, JsonResponse 
from django.contrib.auth.models import User 
from product.models import * 
from django.utils.decorators import method_decorator 
from django.contrib.auth.decorators import login_required 
from datetime import datetime 
from .models import Product as products

class MainProductView(View):
    template = 'product/product.html'

    def get(self,request,*arsg,**kwargs):
        user = User.objects.all()
        name = kwargs.get('name')
        print(name)
        return render(request,self.template,{'users':user})
    
    def post(self,request, *args,**kwargs):
        firstname = request.POST['firstname']
        lastname = request.POST['lastname']
        sex=request.POST['sex']
        return HttpResponse(firstname+" "+lastname+" "+sex)

def get_product(request):
    id = request.GET["id"]  
    return HttpResponse("Get product page = "+id)

def find_bykey(request, id ,name):
    id = id
    name = name
    return HttpResponse("<h1>Finding product: "+id+" Your name is "+name)
def find_product(request,id):
    template = 'product/find_product.html'
    id = id
    return render(request,template,{'my_id':id})


class ProductView(View):
    template_name = 'product/index.html'
    def get(self, request):
        product_list = Category.objects.filter()[:10] 
        print(product_list)
        return render(request, self.template_name, {'data': product_list})

