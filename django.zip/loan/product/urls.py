from django.urls import include, re_path 
from django.conf import settings  
from django.conf.urls.static import static 
 
from product import views as product_view 
from . import views 
from product.views import * 
app_name = 'product' 
 
urlpatterns = [ 
    # url('^home/$', staff_view.home_page, name='home'), 
    re_path('^get_product$', product_view.get_product,name='get_product'),
    re_path('^$', ProductView.as_view(), name='index'), 
    re_path('^mainproduct/(?P<name>\D+)/$', MainProductView.as_view(), name='mainproduct'), 
    re_path('^(?P<id>\w+)$', product_view.find_product,name='find_product_id'), 
    re_path('^(?P<id>\w+)/(?P<name>\D+)$', product_view.find_bykey,name='find_by_key'),


  ] 
if settings.DEBUG: 
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT) 
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)