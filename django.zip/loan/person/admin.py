from django.contrib import admin
from .models import *  
 
admin.site.register(Person)
admin.site.register(Staff)
# Register your models here.
