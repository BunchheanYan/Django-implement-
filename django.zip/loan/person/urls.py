from django.urls import include, re_path
from django.conf import settings  
from django.conf.urls.static import static 
 
from person import views as person_view 
from . import views 
from person.views import * 
app_name = 'person' 
 
urlpatterns = [
    re_path('^$', Index.as_view(), name='index'), # need class
    re_path('^about/contact/$',person_view.contact,name="contact"), # dont need class
    re_path('^about/$',about.as_view(),name="about"),# dont need class
    re_path('^update/(?P<id>\d+)/$', UpdatePerson.as_view(), name='person_update'),
  ] 
if settings.DEBUG: 
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT) 
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)