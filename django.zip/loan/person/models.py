from django.db import models 
from django.urls import reverse 
from django.utils import timezone 
from django.contrib.auth.models import User 
from datetime import date 
import os 
from django.conf import settings 
from django.core.exceptions import ValidationError 
from django.core.validators import RegexValidator 
from ckeditor.fields import RichTextField 
 
# Create your models here. 
sex = ( 
    ('Male', 'Male'), 
    ('Female', 'Female') 
) 
 
def validate_file_extension(value):  
    ext = os.path.splitext(value.name)[1]  # [0] returns path+filename 
    valid_extensions = ['.png', '.jpg', '.jpeg', '.jfif'] 
    if not ext.lower() in valid_extensions: 
        raise ValidationError(u'Unsupported file extension.') 
 
def student_directory_path(request, filename): 
 # return "files/users/%s/%s" % (request.user.id, filename) 
    return '/'.join(['content', request.tel, filename]) 
 
class Person(models.Model):  
    first_name = models.CharField(max_length=50) 
    last_name = models.CharField(max_length=120) 
    sex = models.CharField(max_length=10, choices=sex) 
    dob = models.DateField() 
    email = models.CharField(max_length=120) 
    tel = models.CharField(max_length=20) 
    image =  models.FileField(blank=True, upload_to=student_directory_path,  validators=[validate_file_extension]) 
    description  = RichTextField()



    def __str__(self):
        return str(self.first_name)+' '+str(self.last_name)
    


class Staff(models.Model):
    Person = models.OneToOneField(Person, on_delete=models.CASCADE, name='person_staff')
    salary = models.FloatField()
    tax = models.IntegerField()
    description = RichTextField()
    activate = models.BooleanField(default=True)

    def __str__(self):
        return str(self.person_staff)


