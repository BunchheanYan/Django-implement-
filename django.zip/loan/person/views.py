from django.shortcuts import render, redirect 
from django.views.generic import View, TemplateView  
from django.views import generic 
from django.core.paginator import Paginator 
from django.http import HttpResponse, JsonResponse 
from django.contrib.auth.models import User 
from person.models import * 
from django.utils.decorators import method_decorator 
from django.contrib.auth.decorators import login_required 
from datetime import datetime 
from django.core.exceptions import ObjectDoesNotExist 


class UpdatePerson(View):
    template = 'person/update.html' 

    def get(self, request, *args, **kwargs):  
        id = kwargs.get('id') 
        try:  
            person = Person.objects.get(id=id) 
        except ObjectDoesNotExist:  
            return HttpResponse("ID doesn't exist") 

        return render(request, self.template, {'persons': person}) 

    def post(self, request, *args, **kwargs):
        id = kwargs.get('id')  # Retrieve the ID from kwargs
        try:
            person = Person.objects.get(id=id)

            # Update person fields with data from the form
            person.first_name = request.POST.get('firstname')
            person.last_name = request.POST.get('lastname')
            person.sex = request.POST.get('sex')
            person.dob = request.POST.get('dob')
            person.tel = request.POST.get('tel')
            person.email = request.POST.get('email')
            person.description = request.POST.get('description')

            # Handle file upload
            if request.FILES.get('image'):
                person.image = request.FILES['image']

            person.save()

            return HttpResponse("Update successfully.")
        except ObjectDoesNotExist:
            return HttpResponse("ID doesn't exist")

def contact(self):
    return HttpResponse("Contact")




class about(View):
    template = 'person/about.html'
    def get(self, request):
        dict = Person.objects.filter()[:10] 
        print(dict)
        return render(request,self.template)

        
class Index(View):  
    template = 'person/index.html'
    def get(self, request): 
        data = {
            'name':'Chhoun Chhivhuy '
        }
        person = Person.objects.get(id=1) 
        print(person) 
        print("Firstname is %s lastname is %s sex is %s and email is %s" %(person.first_name, person.last_name, person.sex, person.email)) 
        person1 = Person.objects.filter(id=1)
        return render(request,self.template)


def post(self, request):  
        firstname = request.POST['firstname'] 
        lastname = request.POST['lastname'] 
        sex = request.POST['sex'] 
        dob = request.POST['dob'] 
        dob = datetime.strptime(dob, "%Y-%m-%d").date() 
        tel = request.POST['tel'] 
        email = request.POST['email'] 
        description = request.POST['description'] 
        image = request.FILES.get["image"]  # multivalued dict 
         
        # INSERT INTO Person VALUES(firstname, lastname, ...) 
        person_obj =  Person(first_name=firstname, last_name=lastname, sex=sex, dob=dob, email=email, tel=tel, image = image, description = description) 
        person_obj.save() 
        return redirect('person:index')