from django.shortcuts import render, redirect 
from django.views.generic import View, TemplateView  
from django.views import generic 
from django.core.paginator import Paginator 
from django.http import HttpResponse, JsonResponse 
from django.contrib.auth.models import User 
from userprofile.models import * 
from django.utils.decorators import method_decorator 
from django.contrib.auth.decorators import login_required 
from datetime import datetime 
from django.contrib.auth import authenticate, logout, login


# Create your views here. 

class LoginView(View):
    template = "userprofile/login.html"
    def get(self,request,*arsg,**kwargs):
        return render(request,self.template)
    
    def post(self,request,*arsg,**kwargs):
        username = request.POST['username'] 
        password = request.POST['password'] 
         
        user = authenticate(request, username=username, password=password) 
        if user is not None: 
            login(request, user) 
            return redirect('userprofile:dashboard') 
        else: 
            return render(request, self.template)
        

class LogoutView(View):
    def get(self,request):
        logout(request) 
        return redirect('userprofile:login')
    

class dashboardView(View):
    template = 'userprofile/dashboard.html'
    
    @method_decorator(login_required)
    def get(self, request, *args, **kwargs):
        user_groups = request.user.groups.all()
        if user_groups.exists():
            user_role = user_groups[0].name
        else:
            user_role = "No role assigned"
        users_with_roles = User.objects.prefetch_related('groups')
        users_data = []
        for user in users_with_roles:
            groups = user.groups.all()
            role = groups[0].name if groups.exists() else "No role assigned"
            users_data.append({
                'id': user.id,
                'username': user.username,
                'email': user.email,
                'first_name': user.first_name,
                'last_name': user.last_name,
                'created_date': user.date_joined,
                'role': role,
            })
        context = {
            'user_role': user_role,
            'users_data': users_data,
        }
        return render(request, self.template, context)